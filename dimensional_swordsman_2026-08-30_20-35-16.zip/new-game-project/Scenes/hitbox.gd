extends Area2D

func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("Dimensional_swordsman"):
		global_values.health -= 1
		print("Health: ", global_values.health)
