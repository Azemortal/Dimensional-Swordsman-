extends Area2D

func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("Enemy"):
		global_values.health -= 1 
		print(global_values.health)
	else:
		print("fuck")
	print("fiddle")
