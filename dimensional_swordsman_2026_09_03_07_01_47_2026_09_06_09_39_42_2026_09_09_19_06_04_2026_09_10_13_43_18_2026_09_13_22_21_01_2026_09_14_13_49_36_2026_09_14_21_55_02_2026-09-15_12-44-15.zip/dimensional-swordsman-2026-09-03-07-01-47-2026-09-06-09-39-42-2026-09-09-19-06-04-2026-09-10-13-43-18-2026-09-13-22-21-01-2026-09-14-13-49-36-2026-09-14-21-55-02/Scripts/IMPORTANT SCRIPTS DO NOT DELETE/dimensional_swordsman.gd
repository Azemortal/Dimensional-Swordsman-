extends CharacterBody2D
@onready var animatedsprite = $AnimatedSprite2D

@onready var muzzle: Marker2D = $Muzel
const BULLET_SCENE = preload("res://Scenes/bullet_2d.tscn")
#health
@export var full_health: Texture2D
@export var empty_health: Texture2D
@onready var hearts = [
	$CanvasLayer/DP_containers/Dp_container1,
	$CanvasLayer/DP_containers/Dp_container2,]
@onready var health_bar = $CanvasLayer/Healh_bar
@onready var heath_bar_limiter = $CanvasLayer/Health_limiter
@onready var health_bar_limiter_defalt = heath_bar_limiter.position.x
@onready var Max_health = global_values.Max_health
@onready var attack_timer = $attack_timer
@onready var left_right_attack_hitbox = $Player_Hitbox
@onready var attack_shape = $"left_right attack/CollisionPolygon2D"


func update_hearts():
	#updates the health in the top left
	for i in range(hearts.size()):
		if i < global_values.health:
			hearts[i].texture = full_health
		else:
			hearts[i].texture = empty_health
	health_bar.value = global_values.health_bar_health
	# Move from right to left
	#var health_diffrence = global_values.health_bar_true_max - global_values.health_bar_max_health
	#heath_bar_limiter.position.x = health_bar_limiter_defalt - health_diffrence
	var health_drop_prosess_1 = global_values.health_bar_max_health - global_values.health_bar_gage
	var health_drop_thingamagig = health_drop_prosess_1*2#you only use this for next function 
	heath_bar_limiter.position.x = 156 + health_drop_thingamagig
func damage_blink():
	
	#causes the character to flash when tShey take damage
	for i in range(5):
		animatedsprite.modulate = Color.RED
		await get_tree().create_timer(0.1).timeout
		
		animatedsprite.modulate = Color.WHITE
		await get_tree().create_timer(0.1).timeout
const SPEED = 350. 
const JUMP_VELOCITY = -610.0
const ATTACK_RECOIL = 100.0
const attack_movement = 1400

var attack_recoil = 0.0
#heal movement and input lock
var movement_unlocked = true
var input_lock = false 
#attack varibles
var attack_stage = 0 
var flight_attack_stage = 0
var is_attacking = false 
# var for when in air and want to face the way they were faceing before/ before air
var face_right = true
# var to let the player go through one way tiles
var dropping_through := false
#knockback var
var knockback_velocity = Vector2.ZERO
var knockback_active
func attack(type):
	# left and right attacks 
	if type == "left_right":
		if is_attacking:
			return

		is_attacking = true
		attack_timer.start()
		if attack_stage == 0:
			movement_unlocked = false
			animatedsprite.play("attacking 1")
			if face_right: 
				velocity.x = attack_movement 
				move_and_slide()
			else:
				velocity.x = -attack_movement 
				move_and_slide()
			await get_tree().create_timer(0.4).timeout
			attack_stage = 1
			movement_unlocked = true

		elif attack_stage == 1:
			movement_unlocked = false
			animatedsprite.play("attacking 2")
			if face_right: 
				velocity.x = attack_movement 
				move_and_slide()
			else:
				velocity.x = -attack_movement 
				move_and_slide()
			await get_tree().create_timer(0.4).timeout
			attack_stage = 2
			movement_unlocked = true

		elif attack_stage == 2:
			movement_unlocked = false
			animatedsprite.play("attacking 3")
			if face_right: 
				velocity.x = attack_movement 
				move_and_slide()
			else:
				velocity.x = -attack_movement 
				move_and_slide()
			await get_tree().create_timer(0.4).timeout
			attack_stage = 0
			movement_unlocked = true

		is_attacking = false

		# If left click is still being held, attack again
	elif type == "upslash":
		if is_attacking:
			return
		is_attacking = true
		animatedsprite.play("upslash")
		await get_tree().create_timer(0.4).timeout
		is_attacking = false
	elif type == "downslash":
		if is_attacking:
			return
		is_attacking = true
		animatedsprite.play("downslash")
		await get_tree().create_timer(0.4).timeout
		is_attacking = false
	elif type == "air_slash":
		if is_attacking:
			return
		is_attacking = true
		if attack_stage == 0:
			animatedsprite.play("flying_slash_1")
			await get_tree().create_timer(0.4).timeout
			attack_stage = 1

		elif attack_stage == 1:
			animatedsprite.play("flying_slash_2")
			await get_tree().create_timer(0.4).timeout
			attack_stage = 0

		is_attacking = false
		
func _on_attack_timer_timeout() -> void:
	#attack animation stage for left and right attacks
	attack_stage = 0

func _ready() -> void:
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	update_hearts()
	#Next area spawn point 
	var spawn_point = get_tree().get_meta("spawn_point", "")

	if spawn_point != "":
		var marker = get_tree().current_scene.get_node_or_null(NodePath(spawn_point))


		if marker:
			global_position = marker.global_position
		else:
			print("Spawn point not found(fuck): ", spawn_point)

func _physics_process(delta: float) -> void:
	# Add the gravity.
	if not is_on_floor():
		velocity += get_gravity() * delta
	#shot gun
	if Input.is_action_just_pressed("shoot"):
		shoot_bullet()


	# Handle jump.
	if Input.is_action_just_pressed("ui_accept") and is_on_floor() and movement_unlocked == true and not input_lock:
		velocity.y = JUMP_VELOCITY		
		$Jump_sound.play()
		$walking_dungeon.stop()

	#interactable jump hieght
	if Input.is_action_just_released("ui_accept") and velocity.y < 0 and movement_unlocked == true:
		velocity.y *= 0.5
	#code to alow going through one way tiles
	if Input.is_action_just_pressed("ui_down") :
		set_collision_mask_value(8, false)

		await get_tree().create_timer(0.3).timeout

		set_collision_mask_value(8, true)

	# Get the input direction
	var direction := 0.0

	if not input_lock:
		direction = Input.get_axis("ui_left", "ui_right")

	# Knockback priority over player movement
	if attack_recoil != 0:
		velocity.x = attack_recoil
		attack_recoil = move_toward(attack_recoil, 0, 1000 * delta)
	elif knockback_velocity.x != 0:
		#knockback
		velocity.x = knockback_velocity.x
	
		knockback_velocity.x = move_toward(
			knockback_velocity.x,
			0,
			1000 * delta
		)
	else:
		#player movement stuff
		if direction and movement_unlocked == true:
			velocity.x = direction * SPEED
			if direction > 0:
				face_right = true
			elif direction < 0:
				face_right = false

		elif not is_on_floor():
			velocity.x = 0

		else:
			velocity.x = move_toward(velocity.x, 0, SPEED)
			$walking_dungeon.play()
			
			
	move_and_slide()
	#code to make face right direction when in air
	animatedsprite.flip_h = not face_right

	if face_right:
		left_right_attack_hitbox.position.x = 50
		attack_shape.scale.x = 1
	else:
		left_right_attack_hitbox.position.x = -50
		attack_shape.scale.x = -1
#jumping/falling animation
	if is_attacking == true:
		pass
	elif not is_on_floor():
		if velocity.y<0:
			animatedsprite.play("jumping")
		else: 
			animatedsprite.play("falling")

	# Update animation state
	elif direction != 0 and movement_unlocked == true:
		animatedsprite.play("run")
	else:
		animatedsprite.play("idle")

func attack_recoil_():
	if face_right:
		attack_recoil = -400
	else:
		attack_recoil = 400
		
func player_knockback(enemy_position):
	#player running into enemy knockback
	var x_difference = global_position.x - enemy_position.x
	var direction
	
	if abs(x_difference) < 10:
		# If directly above enemy, use the opposite of current movement
		if velocity.x > 0:
			direction = -1
		elif velocity.x < 0:
			direction = 1
		else:
			direction = -1
	else:
		direction = sign(x_difference)
	
	velocity.x = direction * 500
	velocity.y = -100
	knockback_velocity.x = direction * 500

func down_slash_recoil():
	velocity.y = -500 
	move_and_slide()
	
#when key pressed ____ happens
func _input(event):
	# Completely ignore input while healing
	# R key
	if event is InputEventKey:
		if event.pressed and event.keycode == KEY_R and is_on_floor():
			if global_values.health_bar_health < global_values.health_bar_max_health:
				global_values.health_bar_health += 1
				update_hearts()
				input_lock = true
				movement_unlocked = false
			else:
				input_lock = false
				movement_unlocked = true
	if input_lock:
		if event is InputEventKey and event.keycode == KEY_R and not event.pressed:
			input_lock = false
			movement_unlocked = true
		return
	# Left click attack
	if event is InputEventMouseButton:
		if event.button_index == MOUSE_BUTTON_LEFT and event.pressed and movement_unlocked:
			if Input.is_key_pressed(KEY_W):
				attack("upslash")
			elif Input.is_key_pressed(KEY_S) and not is_on_floor():
				attack("downslash")
			elif Input.is_key_pressed(KEY_S) and is_on_floor():
				pass
			elif not is_on_floor():
				attack("air_slash")
			else:
				attack("left_right")

#bullet function
func shoot_bullet() -> void: 
	var bullet = BULLET_SCENE.instantiate()
	
	var facing_direction:float = -1.0 if animatedsprite.flip_h else 1.0
	
	var spawn_offset: Vector2 = muzzle.position
	spawn_offset.x *= facing_direction
	
	bullet.global_position = global_position + spawn_offset
	bullet.direction = facing_direction
	
	if bullet.has_node("Sprite2D"):
		bullet.get_node("Sprite2D").flip_h = animatedsprite.flip_h
	get_tree().current_scene.add_child(bullet)
	
