extends Area2D
@onready var sprite = $"../AnimatedSprite2D"
@onready var hitbox = $"."
@onready var player = $".."
func _process(_delta):
	if sprite.animation == "attacking 1" or sprite.animation == "attacking 2" or sprite.animation == "attacking 3" or sprite.animation == "flying_slash_1" or sprite.animation == "flying_slash_2":
		if sprite.frame >= 2 and sprite.frame <=3:
			hitbox.monitorable = true
			hitbox.monitoring = true
		else:
			hitbox.monitorable = false
			hitbox.monitoring = false
	else:
		hitbox.monitorable = false
		hitbox.monitoring = false


func _on_area_entered(area: Area2D) -> void:
	var enemy = get_tree().get_first_node_in_group("Enemy_knockback")
	if area.is_in_group("Enemy"):
		enemy.enemy_knockback(global_position)
		
