extends CharacterBody2D

#references the sprite sheet
@onready var animatedsprite = $AnimatedSprite2D
#references the external node
@export var player: Node2D = null
#slime needs speed
@export var speed = 100
@export var knockback_amount = 40000
var direction = 1

var knockback_velocity = Vector2.ZERO

func _ready() -> void:
	player = get_parent().get_node_or_null("Dimensional_swordsman")

	
func _physics_process(delta: float) -> void: 
	#detect the player and draw a vector based on where the player is

	if player:
		if not is_on_floor():
			velocity += get_gravity() * delta
		velocity.x = direction * speed
		animatedsprite.play("block_walk")
		animatedsprite.flip_h = direction < 0

			#add movement code here
		move_and_slide()
		if is_on_wall():
			for i in get_slide_collision_count():
				var collision = get_slide_collision(i)
				var collider = collision.get_collider()
				if collider != player:
					direction *= -1
		
		
func enemy_knockback(player_position):
	#player running into enemy knockback
	var x_difference = global_position.x - player_position.x
	var direction
	
	if abs(x_difference) < 10:
		# If directly above enemy, use the opposite of current movement
		if velocity.x > 0:
			direction = -1
		elif velocity.x < 0:
			direction = 1
		else:
			direction = -1
	else:
		direction = sign(x_difference)
	
	velocity.x = direction * knockback_amount
	velocity.y = -100
	knockback_velocity.x = direction * knockback_amount
