extends CharacterBody2D
@onready var animatedsprite = $AnimatedSprite2D
#health
@export var full_health: Texture2D
@export var empty_health: Texture2D
@onready var hearts = [
	$CanvasLayer/DP_containers/Dp_container1,
	$CanvasLayer/DP_containers/Dp_container2,
	$CanvasLayer/DP_containers/Dp_container3,
	$CanvasLayer/DP_containers/Dp_container4,
	$CanvasLayer/DP_containers/Dp_container5]
@onready var Max_health = global_values.Max_health
func update_hearts():
	for i in range(hearts.size()):
		if i < global_values.health:
			hearts[i].texture = full_health
		else:
			hearts[i].texture = empty_health
func damage_blink():
	for i in range(5):
		animatedsprite.modulate = Color.RED
		await get_tree().create_timer(0.1).timeout
		
		animatedsprite.modulate = Color.WHITE
		await get_tree().create_timer(0.1).timeout
const SPEED = 400.0
const JUMP_VELOCITY = -610.0

# var for when in air and want to face the way they were faceing before/ before air
var face_right = true
# var to let the player go through one way tiles
var dropping_through := false

func _ready() -> void:
	update_hearts()
	#Next area spawn point 
	var spawn_point = get_tree().get_meta("spawn_point", "")

	if spawn_point != "":
		var marker = get_tree().current_scene.get_node_or_null(NodePath(spawn_point))


		if marker:
			global_position = marker.global_position
		else:
			print("Spawn point not found(fuck): ", spawn_point)

func _physics_process(delta: float) -> void:
	# Add the gravity.
	if not is_on_floor():
		velocity += get_gravity() * delta


	# Handle jump.
	if Input.is_action_just_pressed("ui_accept") and is_on_floor():
		velocity.y = JUMP_VELOCITY		
	#interactable jump hieght
	if Input.is_action_just_released("ui_accept") and velocity.y < 0:
		velocity.y *= 0.5
	#code to alow going through one way tiles
	if Input.is_action_just_pressed("ui_down"):
		set_collision_mask_value(8, false)

		await get_tree().create_timer(0.3).timeout

		set_collision_mask_value(8, true)

	# Get the input direction and handle the movement/deceleration.
	var direction := Input.get_axis("ui_left", "ui_right")
   
	if direction:
		velocity.x = direction * SPEED
		#before air code
		if direction > 0:
			face_right = true
		elif direction < 0:
			face_right = false
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)
		
	   
	move_and_slide()
	#code to make face right direction when in air
	animatedsprite.flip_h = not face_right
#jumping/falling animation
	if not is_on_floor():
		if velocity.y<0:
			animatedsprite.play("jumping")
		else: 
			animatedsprite.play("falling")

	# Update animation state
	elif direction != 0:
		animatedsprite.play("run")
	else:
		animatedsprite.play("idle")


	
