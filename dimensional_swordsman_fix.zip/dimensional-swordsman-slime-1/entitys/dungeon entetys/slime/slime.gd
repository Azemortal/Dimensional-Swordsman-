extends CharacterBody2D

#references the sprite sheet
@onready var animatedsprite = $AnimatedSprite2D
#references the external node
@export var player: Node2D = null
#slime needs speed
@export var speed = 100
@export var direction = 1

@onready var rotates =$rotate
@onready var rotates_detection =$rotate/CollisionShape2D
@onready var hitbox = $hitbox
@onready var hitbox_hitbox = $hitbox/CollisionShape2D


var onwall = false
var leftwall = true 
var upsideown = 1
var wall_gravity = 1000
func _ready() -> void:
	player = get_parent().get_node_or_null("Dimensional_swordsman")

	
func _physics_process(delta: float) -> void: 
	#detect the player and draw a vector based on where the player is

	if player:
		if onwall == false:
			if not is_on_floor():
				velocity += get_gravity() * delta * upsideown
			velocity.x = direction * speed * upsideown
			animatedsprite.play("walk")
			if upsideown == -1:
				rotation = 110
			else: 
				rotation = 0
			animatedsprite.flip_h = direction < 0
			
				#add movement code here
			move_and_slide()
			if is_on_wall():
				for i in get_slide_collision_count():
					var collision = get_slide_collision(i)
					var collider = collision.get_collider()
					if collider != player:
						direction *= -1
						
		else:
			if leftwall == true: 
				if not is_on_wall():
					velocity.x -= wall_gravity * delta 
					velocity.y = direction * speed * upsideown
				animatedsprite.play("walk")
				if velocity != Vector2.ZERO:
					rotation = -55
				animatedsprite.flip_h = direction < 0
				move_and_slide()
				if is_on_floor() or is_on_ceiling():
					for i in get_slide_collision_count():
						var collision = get_slide_collision(i)
						var collider = collision.get_collider()
						if collider != player:
							direction *= -1
			else: 
				if not is_on_wall():
					velocity.x += wall_gravity * delta 
					velocity.y = direction * speed * -upsideown
				animatedsprite.play("walk")
				if velocity != Vector2.ZERO:
					rotation = 55
				animatedsprite.flip_h = direction < 0
				move_and_slide()
				if is_on_floor() or is_on_ceiling():
					for i in get_slide_collision_count():
						var collision = get_slide_collision(i)
						var collider = collision.get_collider()
						if collider != player:
							direction *= -1
func knockback(placeholder) -> void:
	pass
func _on_floor_rat_body_exited(body: Node2D) -> void:
	if body is TileMap or body is TileMapLayer:
		if onwall == false and upsideown == 1:
			onwall = true
			leftwall = true 
			upsideown = 1
			#hitbox.rotation_degrees += 90 
			#rotates.rotation_degrees += 0 
		elif onwall == true and leftwall == true:
			upsideown = -1
			leftwall = false 
			onwall = false

		elif onwall == false and upsideown == -1:
			onwall = true
			leftwall = false 
			upsideown = 1

		elif onwall == true and leftwall == false:
			upsideown = 1
			leftwall = false
			onwall = false
