extends CharacterBody2D

@onready var animatedsprite = $AnimatedSprite2D

@export var player: Node2D = null
@export var speed = 100
@export var direction = 1

func _ready() -> void:
	player = get_parent().get_node_or_null("Dimensional_swordsman")


func _physics_process(delta: float) -> void:

	if player:

		# Calculate distance EVERY frame
		var distance = global_position.distance_to(player.global_position)

		if distance <= 400:

			# Find which direction the player is
			var direction_to_player = sign(player.global_position.x - global_position.x)

			# Move toward player
			velocity.x = direction_to_player * speed

			# Flip sprite toward player
			animatedsprite.flip_h = direction_to_player < 0

			animatedsprite.play("walk")
			move_and_slide()
		else:
			if not is_on_floor():
				velocity += get_gravity() * delta
			velocity.x = direction * speed
			animatedsprite.play("walk")
			animatedsprite.flip_h = direction < 0

				#add movement code here
			move_and_slide()
			if is_on_wall():
				for i in get_slide_collision_count():
					var collision = get_slide_collision(i)
					var collider = collision.get_collider()
					if collider != player:
						direction *= -1
