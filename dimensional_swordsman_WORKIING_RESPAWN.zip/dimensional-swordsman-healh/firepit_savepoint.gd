extends Node2D

@export var room_id: String = "room_1"

@onready var animatedsprite = $AnimatedSprite2D

var interacted_in = false
var campfire_state: int = 0


func _ready() -> void:
	# Load this room's campfire state
	if global_values.campfire_states.has(room_id):
		campfire_state = global_values.campfire_states[room_id]

	update_campfire()


func _on_interactable_box_area_entered(area: Area2D) -> void:
	if area.is_in_group("Player_hitbox"):
		interacted_in = true


func _process(delta) -> void:
	if global_values.interacted == true and interacted_in == true:

		if campfire_state == 0:
			campfire_state = 1
			save_campfire()
			update_campfire()

		elif campfire_state == 1: 
			campfire_state = 2
			save_campfire()
			update_campfire()
		elif campfire_state == 2:
			global_values.last_campfire = get_tree().current_scene.scene_file_path


func save_campfire() -> void:
	global_values.campfire_states[room_id] = campfire_state


func update_campfire() -> void:
	if campfire_state == 0:
		animatedsprite.play("unlit")

	elif campfire_state == 1:
		animatedsprite.play("wood")

	elif campfire_state == 2:
		animatedsprite.play("firepit")


func _on_interactable_box_area_exited(area: Area2D) -> void:
	if area.is_in_group("Player_hitbox"):
		interacted_in = false
