extends Node
var Max_health = 2 
var health = 2
var health_bar_health = 128
var health_bar_max_health = 128
var health_bar_gage = 60
var health_bar_true_max = 128
var damage = 5
var interacted = false 
var campfire_states = {}
var last_campfire = "res://Scenes/Levels/Dungeon_room_1.tscn"
