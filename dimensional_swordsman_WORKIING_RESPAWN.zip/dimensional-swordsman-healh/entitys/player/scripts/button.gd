extends Button

func _on_pressed() -> void:
	get_tree().set_meta("spawn_point", "campfire_spawnpoint")
	call_deferred("change_scene")

func change_scene() -> void:
	get_tree().change_scene_to_file(global_values.last_campfire)
