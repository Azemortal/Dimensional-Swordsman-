extends CharacterBody2D

@onready var animatedsprite = $AnimatedSprite2D
@onready var lookout = $lookout
@onready var rat_detection_zone = $lookout/CollisionShape2D

@onready var floor_rat =$floor_rat
@onready var floor_rat_detection =$floor_rat/CollisionShape2D

@export var player: Node2D = null

@export var speed = 100
@export var chase_speed = 200
@export var flee_speed = 300

var direction = 1

var chasing = false
var fleeing = false
var knockback_active = false
var rat_turn = false 

var knockback_velocity = Vector2.ZERO

func _ready() -> void:
	player = get_parent().get_node_or_null("Dimensional_swordsman")


func _physics_process(delta: float) -> void:

	if knockback_active:
		velocity.x = knockback_velocity.x

		knockback_velocity.x = move_toward(
			knockback_velocity.x,
			0,
			1000 * delta
		)

		if not is_on_floor():
			velocity += get_gravity() * delta

		move_and_slide()

		if abs(knockback_velocity.x) < 1:
			knockback_active = false

		return
	if player:

		if fleeing:
			var flee_direction = sign(
				global_position.x - player.global_position.x
			)
			if flee_direction == 0:
				flee_direction = -1

			velocity.x = flee_direction * flee_speed
			animatedsprite.flip_h = flee_direction < 0
			if flee_direction < 0:
				lookout.position.x = 0
				rat_detection_zone.scale.x = 1
				floor_rat.position.x = 0
				floor_rat_detection.scale.x = 1
			else: 
				lookout.position.x = -300
				rat_detection_zone.scale.x = -1
				floor_rat.position.x = -128
				floor_rat_detection.scale.x = -1
			animatedsprite.play("walk")

		elif chasing:
			var direction_to_player = sign(
				player.global_position.x - global_position.x
				)

			velocity.x = direction_to_player * chase_speed
			animatedsprite.flip_h = direction_to_player < 0

			animatedsprite.play("walk")
			var player_distance = abs(player.global_position.x - global_position.x)
			if player_distance > 600:
				chasing = false

		else:

			speed = 100
			velocity.x = direction * speed
			animatedsprite.play("walk")
			animatedsprite.flip_h = direction < 0


	if not is_on_floor():
		velocity += get_gravity() * delta
	move_and_slide()
	if is_on_wall():
		for i in get_slide_collision_count():
			var collision = get_slide_collision(i)
			var collider = collision.get_collider()
			if collider != player:
				direction *= -1
			if direction > 0:
				lookout.position.x = 0
				rat_detection_zone.scale.x = 1
				floor_rat.position.x = 0
				floor_rat_detection.scale.x = 1
			else: 
				lookout.position.x = -300
				rat_detection_zone.scale.x = -1
				floor_rat.position.x = -128
				floor_rat_detection.scale.x = -1
	if rat_turn == true: 
		for i in get_slide_collision_count():
			var collision = get_slide_collision(i)
			var collider = collision.get_collider()
			if collider != player:
				direction *= -1
			if direction > 0:
				lookout.position.x = 0
				rat_detection_zone.scale.x = 1
				floor_rat.position.x = 0
				floor_rat_detection.scale.x = 1
			else: 
				lookout.position.x = -300
				rat_detection_zone.scale.x = -1
				floor_rat.position.x = -128
				floor_rat_detection.scale.x = -1
			rat_turn = false
func _on_lookout_area_entered(area: Area2D) -> void:
	if area.is_in_group("Player_hitbox"):
		chasing = true
		print("yes")
func knockback(enemy_position):
	chasing = true
	knockback_active = true

	var x_difference = global_position.x - enemy_position.x
	var knockback_direction = sign(x_difference)

	if knockback_direction == 0:
		knockback_direction = -1

	knockback_velocity.x = knockback_direction * flee_speed
	velocity.y = -10

	await get_tree().create_timer(0.5).timeout

	knockback_active = false

	# Continue running away
	velocity.x = knockback_direction * flee_speed

	await get_tree().create_timer(0.5).timeout

	velocity.x = 0
	fleeing = false

	# Wait before attacking again
	await get_tree().create_timer(3.0).timeout

	chasing = true

func _on_floor_rat_body_exited(body: Node2D) -> void:
	if body is TileMap or body is TileMapLayer:
		rat_turn = true 
