extends Node
var Max_health = 5 
var health = 5 
