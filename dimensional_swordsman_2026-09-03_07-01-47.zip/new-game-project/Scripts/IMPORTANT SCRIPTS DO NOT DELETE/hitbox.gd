extends Area2D
#timer
@onready var timer = $Timer
#player togles
var player_inside = false
var invincible = false
#runs damage dooer when enter area
func _on_area_entered(area: Area2D) -> void:
	if area.is_in_group("Player_hitbox"):
		player_inside = true
		
		if not invincible:
			damage_player()
#calculate if exited
func _on_area_exited(area: Area2D) -> void:
	if area.is_in_group("Player_hitbox"):
		player_inside = false
#damages player
func damage_player() -> void:
	if invincible:
		return
	
	global_values.health -= 1
	print("Health: ", global_values.health)

	var player = get_tree().get_first_node_in_group("Dimensional_swordsman")
	if player:
		player.update_hearts()
		player.damage_blink()

	# Start 1 second of invincibility
	invincible = true
	timer.start()
#timer shit
func _on_timer_timeout() -> void:
	invincible = false
