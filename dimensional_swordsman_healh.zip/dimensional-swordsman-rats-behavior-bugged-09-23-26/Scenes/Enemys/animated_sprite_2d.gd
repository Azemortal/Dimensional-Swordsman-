extends CharacterBody2D

@onready var animatedsprite = $AnimatedSprite2D
@onready var lookout = $lookout
@onready var rat_detection_zone = $lookout/CollisionShape2D

@export var player: Node2D = null
@export var speed = 100
@export var direction = 1
var inside = false
var knockback_velocity = Vector2.ZERO
var chasing = false 
var knockback_active = false


func _ready() -> void:
	player = get_parent().get_node_or_null("Dimensional_swordsman")


func _physics_process(delta: float) -> void:
	if knockback_active:
		velocity.x = knockback_velocity.x
		knockback_velocity.x = move_toward(
			knockback_velocity.x,
			0,
			1000 * delta
		)

		if abs(knockback_velocity.x) < 1:
			knockback_active = false

		if not is_on_floor():
			velocity += get_gravity() * delta

		move_and_slide()
		return

	if player:

		# Calculate distance EVERY frame
		@warning_ignore("unused_variable")
		var distance = global_position.distance_to(player.global_position)
		if inside == true:
			chasing = true
			@warning_ignore("shadowed_variable")
			speed = 200
			# Find which direction the player is
			var direction_to_player = sign(player.global_position.x - global_position.x)

			# Move toward player
			velocity.x = direction_to_player * speed

			# Flip sprite toward player
			animatedsprite.flip_h = direction_to_player < 0
			if direction_to_player > 0:
				lookout.position.x = 24
				rat_detection_zone.scale.x = 1
			else: 
				lookout.position.x = -300
				rat_detection_zone.scale.x = -1

			animatedsprite.play("walk")
			if not is_on_floor():
				velocity += get_gravity() * delta
			move_and_slide()
		else:
			if not is_on_floor():
				velocity += get_gravity() * delta
			velocity.x = direction * speed
			animatedsprite.play("walk")
			animatedsprite.flip_h = direction < 0

				#add movement code here
			move_and_slide()
			if is_on_wall():
				for i in get_slide_collision_count():
					var collision = get_slide_collision(i)
					var collider = collision.get_collider()
					if collider != player:
						direction *= -1
					speed = 100
					if direction > 0:
						lookout.position.x = 24
						rat_detection_zone.scale.x = 1
					else: 
						lookout.position.x = -300
						rat_detection_zone.scale.x = -1

func _on_lookout_area_entered(area: Area2D) -> void:
	if area.is_in_group("Player_hitbox"):
		inside = true
	else: 
		inside = false
		
func knockback(enemy_position):
	var x_difference = global_position.x - enemy_position.x
	var dierec = sign(x_difference)

	# If we're extremely close horizontally,
	# knock in the opposite direction of current movement.
	if abs(x_difference) < 10:
		if velocity.x > 0:
			dierec = -1
		elif velocity.x < 0:
			dierec = 1
		else:
			dierec = -1

	# IMPORTANT:
	# Change the actual movement direction too.
	direction = dierec

	# Knockback
	knockback_velocity.x = dierec * 300
	velocity.y = -100
	knockback_active = true

	# Face the knockback direction
	if dierec > 0:
		animatedsprite.flip_h = false
		lookout.position.x = 24
		rat_detection_zone.scale.x = 1
	else:
		animatedsprite.flip_h = true
		lookout.position.x = -300
		rat_detection_zone.scale.x = -1

	# Start/stop chasing
	if chasing:
		chasing = false
		inside = false
		speed = 100
	else:
		chasing = true
		inside = true
		speed = 200
