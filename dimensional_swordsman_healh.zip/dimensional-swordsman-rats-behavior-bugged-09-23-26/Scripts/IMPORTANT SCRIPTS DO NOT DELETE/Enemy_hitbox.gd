extends Area2D
#timer
@onready var timer = $Timer
@export var health: int 
@onready var animatedsprite = $"../AnimatedSprite2D"
@export var damage: int
@onready var rat = $".."
#player togles
var player_inside = false
var invincible = false
#runs damage dooer when enter area
func damage_blink():
	#causes the character to flash when they take damage
	for i in range(5):
		animatedsprite.modulate = Color.RED
		await get_tree().create_timer(0.1).timeout
		
		animatedsprite.modulate = Color.WHITE
		await get_tree().create_timer(0.1).timeout
func _on_area_entered(area: Area2D) -> void:
	if area.is_in_group("Player_hitbox"):
		player_inside = true
		
		if not invincible:
			damage_player()
	if area.is_in_group("player_melee_attack"):
		health -= global_values.damage
		print(health)
		if health <= 0:
			#make die permenetly
			$"..".queue_free()
		damage_blink()
		rat.knockback(get_tree().get_first_node_in_group("Dimensional_swordsman").global_position)
#calculate if exited
func _on_area_exited(area: Area2D) -> void:
	if area.is_in_group("Player_hitbox"):
		player_inside = false
#damages player
func damage_player() -> void:
	if invincible:
		return
	
	global_values.health_bar_health -= damage
	if global_values.health_bar_health <= 0:
		global_values.health-= 1
		global_values.health_bar_health = global_values.health_bar_true_max
		global_values.health_bar_max_health = global_values.health_bar_true_max
	if global_values.health_bar_max_health > global_values.health_bar_health + global_values.health_bar_gage:
		global_values.health_bar_max_health = global_values.health_bar_health + global_values.health_bar_gage
	if global_values.health <= 0:
		get_tree().change_scene_to_file("res://Scenes/ui/Death_screen.tscn")
		global_values.health = global_values.Max_health
		global_values.health_bar_health = global_values.health_bar_true_max
		global_values.health_bar_max_health = global_values.health_bar_true_max 
		return

	var player = get_tree().get_first_node_in_group("Dimensional_swordsman")
	if player:
		player.player_knockback(global_position)
		player.update_hearts()
		player.damage_blink()

	# Start 1 second of invincibility
	invincible = true
	timer.start()
#timer shit
func _on_timer_timeout() -> void:
	invincible = false
	if player_inside == true:
		damage_player()

func _process(_delta):
	if animatedsprite.flip_h:
		scale.x = -1
	else:
		scale.x = 1 
