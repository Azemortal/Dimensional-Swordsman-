extends Node
var Max_health = 2 
var health = 2
var health_bar_health = 128
var health_bar_max_health = 128
var health_bar_gage = 60
var health_bar_true_max = 128
var damage = 5
