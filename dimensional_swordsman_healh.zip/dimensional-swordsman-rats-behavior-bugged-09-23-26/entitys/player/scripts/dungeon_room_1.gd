extends Node2D
@export var next_scene: String = "res://dungeon_room_2.tscn"

func _on_body_entered(Dimensional_swordsman):
	if Dimensional_swordsman.is_in_group("Next_area"):
		get_tree().change_scene_to_file(next_scene)
