extends Area2D
#next Area transition code
@export_file("*.tscn") var next_scene: String
@export var spawn_point: String

func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("Dimensional_swordsman"):
		get_tree().set_meta("spawn_point", spawn_point)
		call_deferred("change_scene")


func change_scene() -> void:
	get_tree().change_scene_to_file(next_scene)
#end of transition code
