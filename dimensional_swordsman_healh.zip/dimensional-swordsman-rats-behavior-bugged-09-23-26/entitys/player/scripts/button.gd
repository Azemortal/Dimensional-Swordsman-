extends Button



func _on_pressed() -> void:
	print("faliure")
	get_tree().change_scene_to_file("res://Scenes/Levels/Dungeon_room_1.tscn")
