extends Area2D
@onready var sprite = $"../AnimatedSprite2D"
@onready var hitbox = $"."
@onready var player = $".."
func _process(_delta):
	if sprite.animation == "downslash":
		if sprite.frame >= 2 and sprite.frame <=3:
			hitbox.monitorable = true
			hitbox.monitoring = true
		else:
			hitbox.monitorable = false
			hitbox.monitoring = false
	else:
		hitbox.monitorable = false
		hitbox.monitoring = false


func _on_area_entered(area: Area2D) -> void:
	if area.is_in_group("Enemy"):
		player.attack_recoil_()
		
