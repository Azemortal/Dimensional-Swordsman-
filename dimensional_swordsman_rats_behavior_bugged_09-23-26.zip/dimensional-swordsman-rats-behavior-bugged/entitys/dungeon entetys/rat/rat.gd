extends CharacterBody2D

@onready var animatedsprite = $AnimatedSprite2D
@onready var lookout = $lookout
@onready var rat_detection_zone = $lookout/CollisionShape2D

@export var player: Node2D = null

@export var speed = 100
@export var chase_speed = 200
@export var flee_speed = 300

var direction = 1

var chasing = false
var fleeing = false
var knockback_active = false
var attack_ready = true
var jumping_at_player = false
var retreating = false

var target_position = Vector2.ZERO

var knockback_velocity = Vector2.ZERO

var flashing = false
func flash_white():
	if flashing:
		return
	flashing = true
	var original_modulate = animatedsprite.modulate
	animatedsprite.modulate = Color(5, 5, 5, 1)
	await get_tree().create_timer(0.5).timeout
	animatedsprite.modulate = original_modulate
	await get_tree().create_timer(0.5).timeout
	flashing = false
func wait_until_landed():
	while not is_on_floor():
		await get_tree().physics_frame
func start_jump_attack():
	if not attack_ready:
		return

	attack_ready = false
	jumping_at_player = true

	# Remember where player is
	target_position = player.global_position

	# STOP COMPLETELY
	velocity.x = 0
	velocity.y = 0

	# Flash
	flash_white()

	# Wait for flash
	await get_tree().create_timer(0.5).timeout

	# Make sure we are still stopped
	velocity.x = 0

	# Figure out which direction to jump
	var jump_direction = sign(
		target_position.x - global_position.x
	)

	if jump_direction == 0:
		jump_direction = 1

	# Horizontal leap
	velocity.x = jump_direction * 400
	velocity.y = -100

	animatedsprite.flip_h = jump_direction < 0
	animatedsprite.play("walk")

	# Wait until landing
	await wait_until_landed()

	jumping_at_player = false

	# Check player distance
	var distance_from_player = abs(
		player.global_position.x - global_position.x
	)

	if distance_from_player < 50:
		await retreat_from_player()

	# Wait 3 seconds
	await get_tree().create_timer(3.0).timeout

	attack_ready = true
func retreat_from_player():
	retreating = true
	var direction_away = sign(
		global_position.x - player.global_position.x
	)
	# If somehow exactly on top of the player
	if direction_away == 0:
		direction_away = -1
	velocity.x = direction_away * 100
	var starting_position = global_position.x
	while abs(global_position.x - starting_position) < 100:
		await get_tree().physics_frame
	velocity.x = 0
	retreating = false

func _ready() -> void:
	player = get_parent().get_node_or_null("Dimensional_swordsman")


func _physics_process(delta: float) -> void:

	if knockback_active:
		velocity.x = knockback_velocity.x

		knockback_velocity.x = move_toward(
			knockback_velocity.x,
			0,
			1000 * delta
		)

		if not is_on_floor():
			velocity += get_gravity() * delta

		move_and_slide()

		if abs(knockback_velocity.x) < 1:
			knockback_active = false

		return


	if player:

		if fleeing:
			var flee_direction = sign(
				global_position.x - player.global_position.x
			)

			if flee_direction == 0:
				flee_direction = -1

			velocity.x = flee_direction * flee_speed
			animatedsprite.flip_h = flee_direction < 0
			animatedsprite.play("walk")


		elif chasing and not jumping_at_player and not retreating:

			var distance_from_player = abs(
				player.global_position.x - global_position.x
			)

			if distance_from_player < 300 and attack_ready:
				start_jump_attack()

			else:
				var direction_to_player = sign(
					player.global_position.x - global_position.x
				)

				velocity.x = direction_to_player * chase_speed
				animatedsprite.flip_h = direction_to_player < 0

				animatedsprite.play("walk")


		elif not jumping_at_player and not retreating:

			speed = 100
			velocity.x = direction * speed
			animatedsprite.play("walk")
			animatedsprite.flip_h = direction < 0


	if not is_on_floor():
		velocity += get_gravity() * delta

	move_and_slide()
func _on_lookout_area_entered(area: Area2D) -> void:
	if area.is_in_group("Player_hitbox"):
		chasing = true
func knockback(enemy_position):
	chasing = false
	fleeing = true
	jumping_at_player = false
	attack_ready = false
	knockback_active = true

	var x_difference = global_position.x - enemy_position.x
	var knockback_direction = sign(x_difference)

	if knockback_direction == 0:
		knockback_direction = -1

	knockback_velocity.x = knockback_direction * flee_speed
	velocity.y = -10

	await get_tree().create_timer(0.5).timeout

	knockback_active = false

	# Continue running away
	velocity.x = knockback_direction * flee_speed

	await get_tree().create_timer(0.5).timeout

	velocity.x = 0
	fleeing = false

	# Wait before attacking again
	await get_tree().create_timer(3.0).timeout

	attack_ready = true
	chasing = true
